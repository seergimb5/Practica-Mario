#include "game.hh"
#include "utils.hh"
using namespace pro2;

Game::Game(int width, int height)
    : goku_({ width / 2, 150 }, Keys::Space, Keys::Left, Keys::Right),
    platforms_{
        Platform(100, 300, 200, 211),
        Platform(0, 200, 250, 261),
        Platform(250, 400, 150, 161),
    },
    // goku2_({ width / 2 - 30, 150 }, 'W', 'A', 'D'),
    finished_(false),
    paused_(false),
    bolesdedrac_(),
    frecuenciapaint_(frecuencia_) {
    for (int i = 0; i < 1000; i++) {
        const int stride = i * 200;
        Platform* p;
        BolaDeDrac* bdd;
        if (i % 4 == 0) {
            platforms_.push_back(Platform(stride, 200 + stride, 150, 161));
            bolesdedrac_.push_back(BolaDeDrac({ 100 + stride,140 }, 30));
        }
        else if (i % 4 == 1) {
            platforms_.push_back(Platform(100 + stride, 300 + stride, 200, 211));
            bolesdedrac_.push_back(BolaDeDrac({ 200 + stride,190 }, 50, false));
        }
        else if (i % 4 == 2) {
            platforms_.push_back(Platform(150 + stride, 400 + stride, 150, 161));
            bolesdedrac_.push_back(BolaDeDrac({ 300 + stride,140 }, 30));
        }
        else if (i % 4 == 3) {
            platforms_.push_back(Platform(200 + stride, 500 + stride, 100, 111));
            bolesdedrac_.push_back(BolaDeDrac({ 400 + stride,100 }, 50, false));
        }

    }

    for (int i = 0; i < platforms_.size(); i++) {
        Platform* p = &platforms_[i];
        finder_platforms_.add(p);
    }
    for (int i = 0; i < bolesdedrac_.size(); i++) {
        BolaDeDrac* bdd = &bolesdedrac_[i];
        finder_bolesdedrac_.add(bdd);
    }
}

void Game::process_keys(pro2::Window& window) {
    if (window.is_key_down(Keys::Escape)) {
        finished_ = true;
        return;
    }
    else if (window.was_key_pressed('P')) {
        paused_ = !paused_;
        return;
    }
}

void Game::update_objects(pro2::Window& window) {
    goku_.update(window, platforms_);
    // goku2_.update(window, platforms_);
    auto it = bolesdedrac_.begin();
    while (it != bolesdedrac_.end()) {
        it->update();
        // si interseccionen el goku i la bola de drac elimina la bola de drac del vector i suma la puntuacio al goku i la mostra pel terminal
        if (interseccionan(goku_.get_rect(), it->get_rect())) {
            goku_.increment_puntuacion(BolaDeDrac::get_puntuacion());
            std::cout << goku_.get_puntuacion() << std::endl;
            finder_bolesdedrac_.remove(&(*it));
            it = bolesdedrac_.erase(it);
        }
        else {
            finder_bolesdedrac_.update(&(*it));
            it++;
        }
    }
}

void Game::update_camera(pro2::Window& window) {
    const pro2::Pt pos = goku_.pos();
    const pro2::Pt cam = window.camera_center();

    const int left = cam.x; //- window.width() / 4;
    const int right = cam.x; //+ window.width() / 4;
    const int top = cam.y - window.height() / 4;
    const int bottom = cam.y + window.height() / 4;


    int dx = 0, dy = 0;
    if (pos.x > right) {
        dx = pos.x - right;
    }
    else if (pos.x < left) {
        dx = pos.x - left;
    }
    if (pos.y < top) {
        dy = pos.y - top;
    }
    else if (pos.y > bottom) {
        dy = pos.y - bottom;
    }
    window.move_camera({ dx, dy });
}

void Game::update(pro2::Window& window) {
    process_keys(window);
    if (!paused_) {
        update_objects(window);
        update_camera(window);
    }
}

void Game::paint(pro2::Window& window) {
    window.clear(sky_blue);
    pro2::Rect cam = window.camera_rect();
    const set<const Platform*>& platforms_in_camera = finder_platforms_.query(cam);
    const set<const BolaDeDrac*>& boles_in_camera = finder_bolesdedrac_.query(cam);
    for (const Platform* p : platforms_in_camera) {
        p->paint(window);
    }
    for (const BolaDeDrac* bdd : boles_in_camera) {
        bdd->paint(window);
    }
    goku_.paint(window);
    //goku2_.paint(window);
    paint_hline(window, cam.left, cam.right, cam.top);
    paint_hline(window, cam.left, cam.right, cam.bottom - 1);
    paint_vline(window, cam.left, cam.top, cam.bottom - 1);
    paint_vline(window, cam.right - 1, cam.top, cam.bottom - 1);

}